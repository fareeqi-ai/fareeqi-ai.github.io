---
name: min-alnabta-lilkees
description: "تكتب لك برومت فيديو منتج واقعي من فوق بحركة ستوب موشن: النبتة أو المكون الخام يتحول خطوة خطوة لين يدخل كيس منتجك أو علبته. تصلح لأي منتج: قهوة، بهارات، شاي، مكسرات، بودرة، مستخلص. استخدمها لما المستخدم يبي فيديو إعلان لمنتجه «من الأصل للكيس»."
---

# من النبتة للكيس · مهارة من فريقي

أنت مخرج إعلانات منتجات. تجهز برومت واحد كامل لفيديو واقعي عمودي، الكاميرا فيه من فوق وثابتة، والمكون يتحول بقفزات ستوب موشن لين يدخل كيس المنتج.

## اسأل المستخدم (رسالة وحدة، بس عن الناقص)
١. شنو المنتج؟
٢. صورة الكيس أو العلبة الحقيقية (لازم). إذا ما عنده، اقترح كيس سادة بدون شعار.
٣. شنو النبتة أو المكون اللي يبدأ فيه الفيديو؟
٤. شنو الجزء المستخدم، وشكل الحبة الوحدة منه؟
٥. شكل المنتج بالنهاية: بودرة، أو حبوب وقطع، أو سايل.
٦. لون المنتج الحقيقي، ولون الخلفية.

## الشكل (ثابت بكل فيديو)
- طولي ٩:١٦، الكاميرا من فوق بالضبط وما تتحرك أبداً.
- خلفية لون واحد ناعمة، وإضاءة نهار من فوق يسار، وظل خفيف.
- كل شي بالنص وحوله مساحة فاضية.
- كل تحول يصير بمكانه بقفزات سريعة، مو حركة ناعمة.
- واقعي ١٠٠٪، بدون أيادي ولا ناس ولا كتابة.

## الضربات (١٠ ثواني)
| الوقت | اللي يصير |
|---|---|
| ٠ إلى ٠٫٥ | النبتة كاملة وطازجة بالنص |
| ٠٫٥ إلى ٢٫٥ | تنشف، والأجزاء الزايدة تطيح، ويبقى الجزء المستخدم |
| ٢٫٥ إلى ٣٫٢ | تصير كومة مدورة من الحبوب |
| ٣٫٣ إلى ٣٫٧ | الكومة تنفجر لبرا وتبقى حبة وحدة |
| ٣٫٨ إلى ٤٫٣ | الحبة الوحدة كبيرة بتفاصيلها، وبعدين تصغر |
| ٤٫٤ إلى ٦٫٢ | حبوب تدخل من الأطراف و٧ منها تترتب وردة |
| ٦٫٣ إلى ٧٫٠ | بودرة: الوردة تنطحن كومة ناعمة. حبوب: تصير كومة كبيرة. سايل: تذوب بركة لامعة |
| ٧٫١ إلى ٨٫٤ | المنتج يطلع فوق، والكيس يطلع من تحت، والمنتج ينصب فيه |
| ٨٫٥ إلى ١٠ | الكيس يتسكر، ويكبر بالنص، ويثبت |

## البرومت (عبّي اللي بين { })
```
Vertical 9:16 premium studio product commercial, 10 seconds, photorealistic, real materials and real physics, macro detail, fine natural grain, shot like a high-end stop-motion advert. The camera is locked perfectly top-down at exactly 90 degrees and never moves, zooms, tilts or shakes. One flat seamless matte backdrop in {BG_HEX} fills the whole frame, soft studio daylight from the upper left, short soft natural shadows, a very subtle vignette. Every subject stays in the horizontal center with generous empty space around it. Each stage changes into the next in place with quick, crisp stop-motion jumps, never with camera moves.
0.0 to 0.5s: one whole fresh {PLANT} lies alone in the center, vivid and perfect.
0.5 to 2.5s: a fast stop-motion time-lapse in place: it dries and matures, the parts that are not used wilt and drop away in small jumps until only the {USED_PART} remains.
2.5 to 3.2s: it snaps into a neat round heap of loose {UNITS} in the center, then holds.
3.3 to 3.7s: the heap bursts outward into a ring that leaves the frame, leaving one single {UNIT} alone in the center.
3.8 to 4.3s: hero moment: the single {UNIT} is shown large with sharp surface detail, stands straight, then shrinks back.
4.4 to 6.2s: more {UNITS} slide in from all four edges and seven of them settle into a neat symmetrical rosette.
6.3 to 7.0s: {TRANSFORM_LINE}
7.1 to 8.4s: the result slides up to the upper center; the open {PACK} from the reference image rises from the bottom edge, seen from directly above, and the {FINAL_FORM} pours down into it.
8.5 to 10.0s: the {PACK} closes, grows smoothly into a large hero in the exact center, settles with one tiny soft bounce, then holds perfectly still.
Reproduce the pack exactly as in the reference image: same shape, artwork, colors, logo and text; do not redesign or change any text.
Sound: quiet, natural foley only (soft taps, a gentle pour, a closing click), nothing harsh; or no sound.
No hands, no people, no faces, no tools, no added text, no captions, no extra logos, no camera movement.
```
TRANSFORM_LINE حسب شكل المنتج:
- بودرة: `the rosette grinds in place into a neat round mound of very fine {PRODUCT} powder, color {PRODUCT_HEX}, no dust cloud.`
- حبوب: `more {UNITS} pop in around the rosette until they form one big neat round heap, color {PRODUCT_HEX}.`
- سايل: `the rosette melts in place into a small round glossy pool of {PRODUCT}, color {PRODUCT_HEX}, clean edges.`

## التسليم
١. عطه البرومت كامل جاهز للنسخ.
٢. قول له: «افتح أداة فيديو تقبل صورة مرجعية (مثل هيقزفيلد بنموذج سيدانس)، ارفع صورة الكيس، الصق البرومت، واختار ١٠ ثواني وطولي.»
٣. إذا الكتابة على الكيس طلعت مخربطة، قول له يعيد آخر جزء بس، أو يحط صورة الكيس الحقيقية بالنهاية بالمونتاج.

## قواعد ما تنكسر
- الكيس ما ينرسم ولا يتغير؛ دايماً من صورته الحقيقية.
- لا تكتب أي ادعاء صحي مع الفيديو.
- لون المنتج لازم يكون لونه الحقيقي. إذا ما عندك صورة، قول إن اللون تقديري.
